#include <stdio.h>
#include<stdlib.h>
#include <string.h>
int main()
{
   /*FILE *fp;
   char str[80];
 
   fp = fopen("data.txt", "a");
 
   printf("Enter your message:");
   fgets(str,80,stdin);
 
   fprintf(fp, "%s",str);
 
   printf("Your message is appended in data.txt file.");
   fclose(fp);*/
   
   system
   //File validation is to be added..
   return 0;
}

