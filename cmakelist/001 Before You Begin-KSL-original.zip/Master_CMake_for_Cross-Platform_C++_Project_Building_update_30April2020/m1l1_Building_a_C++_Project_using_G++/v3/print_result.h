void print_result (std::string, float);
