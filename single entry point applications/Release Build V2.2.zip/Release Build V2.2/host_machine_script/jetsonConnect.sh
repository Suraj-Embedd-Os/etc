#!/bin/bash
sshpass -p "86yxfURVtbA5" ssh -t -t toad@192.168.60.207 "cd /home/toad/AcepipeWorkspace && export DISPLAY=:0 &&  bash -c /home/toad/AcepipeWorkspace/src/startup.sh"
