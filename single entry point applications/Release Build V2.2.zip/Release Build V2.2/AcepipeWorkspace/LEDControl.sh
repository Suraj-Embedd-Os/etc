#!/bin/bash
python3 /home/toad/AcepipeWorkspace/LEDControl.py $1
