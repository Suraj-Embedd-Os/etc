#!/bin/bash

gcc post_processing_data.c -o post_processing_data
 
./post_processing_data

